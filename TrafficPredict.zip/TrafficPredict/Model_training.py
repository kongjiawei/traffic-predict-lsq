 # import matplotlib.pyplot as plt
import xlrd
import numpy as np
import tensorflow as tf
# import math
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
import time
start = time.clock()

from keras.models import load_model
# file location
pattern = 'Traffic'
xlsx_file_name =   pattern + '.xlsx'
trainingSampleNum = 160000
testSampleNum = 10000
look_back = 168*2
predictSampleNum = 24


def creat_dataset(data, look_back):
    dataX, dataY=[], []
    for i in range(len(data)-look_back-predictSampleNum - 1):
        dataX.append(data[i:(i+look_back)])
        dataY.append(data[(i+look_back):(i+look_back + predictSampleNum)])
        # dataY.append(data[(i + look_back)])
    return np.array(dataX), np.array(dataY)


# extract data 'data' store the whole training data set
data = xlrd.open_workbook(xlsx_file_name).sheet_by_index(0).col_values(0)[0:0+trainingSampleNum]
dataset = list(data)


trainX, trainY = creat_dataset(dataset[0:trainingSampleNum], look_back)
testX, testY = creat_dataset(dataset[trainingSampleNum:trainingSampleNum + testSampleNum], look_back)
trainX = np.reshape(trainX, (trainX.shape[0], 1, trainX.shape[1]))


# # create model
model = Sequential()
# model.add(LSTM(64, return_sequences=True, input_shape=(1, look_back)))
# model.add(LSTM(64, return_sequences=True))
model.add(LSTM(32, input_shape=(1, look_back), return_sequences=True))
# model.add(LSTM(512, return_sequences=True))
model.add(LSTM(256))


# model.add(LSTM(1024, return_sequences=True))

model.add(Dense(predictSampleNum, activation='sigmoid'))
model.compile(loss='mean_squared_error', optimizer='Adam', metrics=['accuracy'])
print(model)
sess = tf.Session(config=tf.ConfigProto(log_device_placement=True))
model.fit(trainX, trainY, epochs=1, batch_size=30)
model.save(pattern +'2L' +'.h5')
print('model have saved')
elapsed = (time.clock() - start)
print("Time used:", elapsed)
