import matplotlib.pyplot as plt
# import csv
import xlrd
import numpy as np
# import tensorflow as tf
# import math
# from keras.models import Sequential
# from keras.layers import Dense
# from keras.layers import LSTM
from keras.models import load_model
# import time

pattern = 'Traffic'
xlsx_file_name = '/home/liusq/TrafficPredict/' + pattern + '.xlsx'
trainingSampleNum = 160000
testSampleNum = 10000
look_back = 168*2
predictSampleNum = 24
model = load_model(pattern +'2L' + '.h5')



def creat_testdata(data):
    test_input = []
    for i in range((len(data)-look_back)//predictSampleNum):
        test_input.append(data[predictSampleNum*i:predictSampleNum*i+look_back])
    return np.array(test_input)


testDataSet = xlrd.open_workbook(xlsx_file_name).sheet_by_index(0).col_values(0)[trainingSampleNum:testSampleNum+trainingSampleNum]
test_inputdata = creat_testdata(testDataSet)
test_inputdata = np.reshape(test_inputdata, (test_inputdata.shape[0], 1, test_inputdata.shape[1]))

predicted_data = []
predicted_temp = []
for i in range(test_inputdata.shape[0]):
    test_temp = np.array([test_inputdata[i, :, :]])
    Predict = model.predict(test_temp)
    predicted_temp = predicted_temp + list(Predict[0, :])


actual = testDataSet[look_back:look_back-1+len(predicted_temp)]
relativeError = []
for i in range(len(actual)):
    relativeError.append(abs(actual[i] - predicted_temp[i])/actual[i])
avgRelativeErr = np.mean(relativeError)

prediction = open("/home/liusq/TrafficPredict/prediction_results.dat", "w+")
for elements in predicted_temp:
    prediction.write(str(elements)+'\n')
actualfile = open("/home/liusq/TrafficPredict/actual_results.dat", "w+")
for elements in actual:
    actualfile.write(str(elements)+'\n')
prediction.close()
actualfile.close()

errorFile = open("/home/liusq/TrafficPredict/error.dat", "w+")
for elements in relativeError:
    errorFile.write(str(elements)+'\n')
errorFile.close()


plt.plot(predicted_temp[1000:2000], label='predicted')
plt.plot(actual[1000:2000], label='true')
plt.legend()
plt.savefig('Results/traffic.png')
plt.show()


n = plt.hist(np.array(relativeError), bins=20, range=(0, 0.2))
plt.savefig('Results/relativeError.png')
plt.xticks(np.arange(0, 0.2, 0.02))
print(np.sum(n[0]))

plt.show()

